# Guía Práctica 2 – Docker Lab (MySQL/MariaDB Backups + PITR)

Este proyecto crea un laboratorio reproducible para demostrar:
- Backup FULL con `mysqldump` (incluye coordenadas `CHANGE MASTER TO`).
- Backup INCREMENTAL basado en **rotación y copia de binlogs** (`FLUSH LOGS` + copiar `mysql-bin.*`).
- Recuperación Point-in-Time (PITR) aplicando binlogs hasta antes del desastre.

## Requisitos
- Docker + Docker Compose (v2)
- `mysqlbinlog` instalado en el host (paquete `mariadb-client` o `mysql-client` según distro)

## Levantar ambiente
```bash
cd guia_practica2_docker
./scripts/00_up.sh
```

## Demo (Paso a paso)
1) Ver datos iniciales (se cargan por init script):
```bash
./scripts/01_show_data.sh
```

2) Backup FULL (Domingo):
```bash
./scripts/02_full_backup.sh
```

3) Insertar datos nuevos (Lunes):
```bash
./scripts/03_simulate_monday.sh
```

4) Backup INCREMENTAL (rotar binlogs y copiar cerrados):
```bash
./scripts/04_incremental_backup.sh
```

5) Desastre (Martes): drop table
```bash
./scripts/05_disaster.sh
```

6) Recuperación (Full + Binlog replay):
```bash
./scripts/06_recovery_pitr.sh
```
Luego, ejecute el comando sugerido con `--stop-position` o `--stop-datetime` para excluir el DROP.

## Notas de la guía
- La guía explica que el FULL permite ver `CHANGE MASTER TO` como coordenada del binlog (inicio para PITR).
- El incremental se basa en `flush-logs` para cerrar el binlog con los cambios y abrir uno nuevo, luego copiar el archivo cerrado.

