# Caso Práctico 2 – Respuesta (El Desastre en FinTech Corp)

## 1) ¿Qué archivos se necesitan para restaurar?
- Backup FULL del domingo.
- Backups incrementales desde lunes hasta el incremental más reciente antes del incidente (jueves 02:00 AM).
- (Para PITR real) Binlogs / transaction logs desde el último backup hasta el punto objetivo (por ejemplo, cada 15 minutos).

## 2) ¿Cuál es la pérdida de datos (RPO real)?
Con incrementales solo a las 02:00, el punto más reciente recuperable es jueves 02:00.
Incidente: jueves 16:00. Pérdida = 14 horas de transacciones.

## 3) Solución propuesta para reducir RPO
- Usar backups diferenciales diarios (reduce tiempo/volumen frente a full diario en una BD grande).
- Implementar backups de logs (binlog / transaction log) cada 15 minutos, permitiendo PITR a minutos.
- Resultado esperado: RPO máximo 15 minutos.
