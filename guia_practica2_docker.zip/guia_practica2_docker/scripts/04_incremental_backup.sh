#!/usr/bin/env bash
set -euo pipefail
./scripts/backup_manager.sh inc
echo "[*] Incremental folders:"
ls -lah ./backups/clase_demo | sed -n '1,200p'
