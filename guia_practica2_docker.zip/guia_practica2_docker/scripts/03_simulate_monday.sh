#!/usr/bin/env bash
set -euo pipefail
docker exec -i guia2-mysql mariadb -uroot -prootpass -e "USE empresa; INSERT INTO ventas (producto) VALUES ('Monitor Samsung'), ('Teclado Mecánico'); SELECT * FROM ventas;"
