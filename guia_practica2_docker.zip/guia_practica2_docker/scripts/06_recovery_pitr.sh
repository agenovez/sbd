#!/usr/bin/env bash
set -euo pipefail

# 1) Restore latest full backup
latest_full=$(ls -1t ./backups/clase_demo/full_backup_*.sql.gz | head -n1)
echo "[*] Restoring FULL backup: ${latest_full}"

# Drop & recreate schema for a clean restore
docker exec -i guia2-mysql mariadb -uroot -prootpass -e "DROP DATABASE IF EXISTS empresa;"
zcat "${latest_full}" | docker exec -i guia2-mysql mariadb -uroot -prootpass

echo "[*] After FULL restore (expected: only Laptop+Mouse):"
docker exec -i guia2-mysql mariadb -uroot -prootpass -e "USE empresa; SELECT * FROM ventas;"

# 2) Identify latest incremental binlog folder
inc_dir=$(ls -1dt ./backups/clase_demo/incrementales_* | head -n1)
echo "[*] Using incremental folder: ${inc_dir}"
binlog=$(ls -1 "${inc_dir}"/mysql-bin.* 2>/dev/null | head -n1 || true)
if [[ -z "${binlog}" ]]; then
  echo "ERROR: No mysql-bin.* found in ${inc_dir}. Run incremental step first." >&2
  exit 1
fi

echo "[*] Inspecting binlog to locate DROP position (searching 'DROP TABLE')..."
# Use verbose decode to find line numbers and potential end positions.
# We'll capture the first occurrence to help choose --stop-position.
mysqlbinlog --base64-output=DECODE-ROWS -vv "${binlog}" | grep -n "DROP TABLE" -n || true
echo "[!] Choose a stop-position BEFORE the DROP event. If you don't want to choose,"
echo "    you can use --stop-datetime with the timestamp just before the DROP."

echo "[*] Replaying binlog into server (you may need to edit with stop options)."
echo "    Example (manual): mysqlbinlog --stop-position=<POS> ${binlog} | docker exec -i guia2-mysql mariadb -uroot -prootpass"
