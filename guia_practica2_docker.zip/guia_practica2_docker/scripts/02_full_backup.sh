#!/usr/bin/env bash
set -euo pipefail
./scripts/backup_manager.sh full
latest=$(ls -1t ./backups/clase_demo/full_backup_*.sql.gz | head -n1)
echo "[*] Latest full backup: ${latest}"
echo "[*] Binlog coordinates line:"
zcat "${latest}" | grep -m1 -n "CHANGE MASTER TO" || true
