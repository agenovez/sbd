\
#!/usr/bin/env bash
set -euo pipefail

# backup_manager.sh
# full  -> creates a compressed logical backup (mysqldump) and stores binlog coordinates (CHANGE MASTER TO)
# inc   -> rotates binlogs (FLUSH LOGS) and copies the closed binlog(s) to /backups
#
# Expected environment (defaults work with docker-compose here):
#   MYSQL_HOST, MYSQL_PORT, MYSQL_USER, MYSQL_PASSWORD, MYSQL_DB
#   BACKUP_DIR

MYSQL_HOST="${MYSQL_HOST:-127.0.0.1}"
MYSQL_PORT="${MYSQL_PORT:-3307}"
MYSQL_USER="${MYSQL_USER:-root}"
MYSQL_PASSWORD="${MYSQL_PASSWORD:-rootpass}"
MYSQL_DB="${MYSQL_DB:-empresa}"
BACKUP_DIR="${BACKUP_DIR:-./backups/clase_demo}"

mkdir -p "${BACKUP_DIR}"

ts() { date +"%Y%m%d_%H%M%S"; }

mysql_cli() {
  mysql --protocol=tcp -h "${MYSQL_HOST}" -P "${MYSQL_PORT}" -u "${MYSQL_USER}" -p"${MYSQL_PASSWORD}" "$@"
}

die() { echo "ERROR: $*" >&2; exit 1; }

case "${1:-}" in
  full)
    out="${BACKUP_DIR}/full_backup_$(ts).sql.gz"
    echo "[*] Creating FULL backup to ${out}"
    # --master-data=2 writes a commented CHANGE MASTER TO line with binlog file/pos coordinates.
    mysqldump --protocol=tcp -h "${MYSQL_HOST}" -P "${MYSQL_PORT}" -u "${MYSQL_USER}" -p"${MYSQL_PASSWORD}" \
      --single-transaction --routines --events --triggers \
      --master-data=2 --databases "${MYSQL_DB}" | gzip -9 > "${out}"
    echo "[*] Done. Tip: inspect coordinates with: zcat ${out} | grep -m1 -n \"CHANGE MASTER TO\""
    ;;

  inc)
    inc_dir="${BACKUP_DIR}/incrementales_$(ts)"
    mkdir -p "${inc_dir}"
    echo "[*] Rotating binlogs (FLUSH LOGS) ..."
    mysql_cli -e "FLUSH LOGS;"
    echo "[*] Discovering current binlogs ..."
    # We'll copy all binlogs except the *active* (latest) one.
    mapfile -t logs < <(mysql_cli -Nse "SHOW BINARY LOGS;" | awk '{print $1}')
    [[ "${#logs[@]}" -ge 1 ]] || die "No binlogs found. Ensure log_bin is enabled."
    active="${logs[-1]}"
    echo "[*] Active binlog is: ${active}. Copying closed binlogs to ${inc_dir}"
    for f in "${logs[@]}"; do
      if [[ "${f}" == "${active}" ]]; then
        continue
      fi
      src="/var/lib/mysql/${f}"
      # Copy from the container's filesystem using docker cp (works even from host)
      docker cp guia2-mysql:"${src}" "${inc_dir}/" >/dev/null
      echo "    - copied ${f}"
    done
    echo "[*] Also copying binlog index (optional) ..."
    docker cp guia2-mysql:/var/lib/mysql/mysql-bin.index "${inc_dir}/" >/dev/null || true
    echo "[*] Incremental capture complete: ${inc_dir}"
    ;;

  *)
    cat <<'USAGE'
Usage:
  ./scripts/backup_manager.sh full
  ./scripts/backup_manager.sh inc

Defaults assume docker-compose environment:
  MYSQL_HOST=127.0.0.1
  MYSQL_PORT=3307
  MYSQL_USER=root
  MYSQL_PASSWORD=rootpass
  MYSQL_DB=empresa
  BACKUP_DIR=./backups/clase_demo
USAGE
    exit 2
    ;;
esac
