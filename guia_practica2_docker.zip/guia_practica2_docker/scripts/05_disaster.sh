#!/usr/bin/env bash
set -euo pipefail
docker exec -i guia2-mysql mariadb -uroot -prootpass -e "USE empresa; DROP TABLE ventas;"
echo "[*] Disaster executed: ventas dropped."
