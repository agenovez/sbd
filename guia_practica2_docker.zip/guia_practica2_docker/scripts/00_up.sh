#!/usr/bin/env bash
set -euo pipefail
docker compose up -d
echo "[*] Waiting for MySQL to be healthy..."
docker compose ps
