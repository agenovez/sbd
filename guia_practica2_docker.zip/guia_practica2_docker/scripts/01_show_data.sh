#!/usr/bin/env bash
set -euo pipefail
docker exec -i guia2-mysql mariadb -uroot -prootpass -e "USE empresa; SELECT * FROM ventas;"
