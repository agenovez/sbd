-- Auto-provision demo schema
CREATE DATABASE IF NOT EXISTS empresa;
USE empresa;

CREATE TABLE IF NOT EXISTS ventas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  producto VARCHAR(50) NOT NULL
);

INSERT INTO ventas (producto) VALUES ('Laptop Dell'), ('Mouse Logitech');
