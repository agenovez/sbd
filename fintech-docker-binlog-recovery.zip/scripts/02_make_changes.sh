#!/usr/bin/env bash
docker exec -i fintech-mysql mysql -uroot -prootpass fintech <<'SQL'
INSERT INTO clientes (nombre, saldo) VALUES ('Cliente Jueves 3PM', 5000.00);
INSERT INTO clientes (nombre, saldo) VALUES ('Cliente Jueves 3:30PM', 250.00);
SELECT * FROM clientes;
SQL
