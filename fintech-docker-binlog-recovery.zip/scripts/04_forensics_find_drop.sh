#!/usr/bin/env bash
docker exec -i fintech-mysql mysql -uroot -prootpass -e "SHOW BINARY LOGS;"
docker exec -i fintech-mysql bash -lc '
for f in /var/lib/mysql/mysql-bin.*; do
  mysqlbinlog --base64-output=DECODE-ROWS -vv "$f" | grep "DROP TABLE" || true
done
'
