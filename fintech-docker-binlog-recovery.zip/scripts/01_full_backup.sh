#!/usr/bin/env bash
docker exec -i fintech-mysql bash -lc '
  mkdir -p /backups
  mysqldump -uroot -prootpass --databases fintech --single-transaction --routines --triggers     > /backups/full_$(date +%F_%H%M%S).sql
  mysql -uroot -prootpass -e "SHOW BINARY LOGS;"
'
