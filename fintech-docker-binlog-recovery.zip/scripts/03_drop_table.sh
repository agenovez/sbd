#!/usr/bin/env bash
docker exec -i fintech-mysql mysql -uroot -prootpass fintech -e "DROP TABLE clientes;"
