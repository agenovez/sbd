#!/usr/bin/env bash
LAST_BACKUP=$(ls -1 ./backups/full_*.sql | tail -n 1)
cat "$LAST_BACKUP" | docker exec -i fintech-mysql mysql -uroot -prootpass

BINLOG_FILE="mysql-bin.000001"
STOP_POSITION="12345"

docker exec -i fintech-mysql bash -lc "
mysqlbinlog /var/lib/mysql/${BINLOG_FILE} --stop-position=${STOP_POSITION} | mysql -uroot -prootpass
"

docker exec -i fintech-mysql mysql -uroot -prootpass fintech -e "SELECT * FROM clientes;"
