# Evaluación Práctica MariaDB con Docker

Entorno reproducible con auditoría mediante triggers.
