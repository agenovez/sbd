USE evaluacion_db;
UPDATE usuarios SET nombre='Juan Actualizado' WHERE id=1;
