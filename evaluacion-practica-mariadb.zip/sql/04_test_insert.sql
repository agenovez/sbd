USE evaluacion_db;
INSERT INTO usuarios(nombre,correo) VALUES('Juan Perez','juan@correo.com');
