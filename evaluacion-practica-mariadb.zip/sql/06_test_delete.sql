USE evaluacion_db;
DELETE FROM usuarios WHERE id=1;
