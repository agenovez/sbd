USE evaluacion_db;
DELIMITER //
CREATE TRIGGER trg_insert_usuario AFTER INSERT ON usuarios
FOR EACH ROW BEGIN
 INSERT INTO auditoria_usuarios(usuario_id,accion,detalle)
 VALUES(NEW.id,'INSERT',CONCAT('Usuario creado: ',NEW.nombre));
END//
DELIMITER ;
